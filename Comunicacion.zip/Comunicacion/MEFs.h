/*
 * MEFs.h
 *
 *  Created on: 17 dic. 2023
 *      Author: gasti
 */

#ifndef MEFS_H_
#define MEFS_H_

#include "driverlib.h"
#include "device.h"

//---------------- MEF Acci�n ----------------
typedef enum {
    Reset = 0,
    Reposo,
    Homming,
    Trans_HS,
    Trans_Temp,
    Trans_Corr,
    Trans_Pos,
    Almacenar_ref,
}Enum_est_Accion;

//---------------- MEF Recepci�n ----------------
typedef enum
{
    reposo = 0,
    comando,
    J1B1,
    J1B2,
    J2B1,
    J2B2,
    J3B1,
    J3B2,
}Enum_est_Recep;

typedef enum
{
    Nada = 0,
    Inicializar,
    Home_switch,
    Temperaturas,
    Corrientes,
    Posiciones,
    Referencias,
}Comando_recibido_enum;

//Los siguientes bits los voy a leer �nicamente si llega un R
#define b0(x)         (x == 'I' || x == 'H' || x == 'T' || x == 'C' || x == 'P' || x == 'R') //Comandos

extern int instruccion;        // Frame check flag.
/*==================[MEFs]==========================*/

//---------------- MEF recepci�n ----------------
void MEF_Recepcion(void);

//---------------- MEF accion -------------------
void MEF_Transmision(void);



#endif /* MEFS_H_ */
