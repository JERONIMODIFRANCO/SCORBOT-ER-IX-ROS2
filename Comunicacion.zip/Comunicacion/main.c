//#############################################################################
//
// FILE:   sci_ex3_echoback.c
//
// TITLE:  SCI echoback example.
//
//! \addtogroup driver_example_list
//! <h1>SCI Echoback</h1>
//!
//!  This test receives and echo-backs data through the SCI-A port.
//!
//!  A terminal such as 'putty' can be used to view the data from
//!  the SCI and to send information to the SCI. Characters received
//!  by the SCI port are sent back to the host.
//!
//!  \b Running \b the \b Application
//!  Open a COM port with the following settings using a terminal:
//!  -  Find correct COM port
//!  -  Bits per second = 9600
//!  -  Data Bits = 8
//!  -  Parity = None
//!  -  Stop Bits = 1
//!  -  Hardware Control = None
//!
//!  The program will print out a greeting and then ask you to
//!  enter a character which it will echo back to the terminal.
//!
//!  \b Watch \b Variables \n
//!  - loopCounter - the number of characters sent
//!
//! \b External \b Connections \n
//!  Connect the SCI-A port to a PC via a USB cable.
//!  Refer to the hardware user guide for the UART/USB connector information.
//
//#############################################################################
//
// 
// $Copyright:
// Copyright (C) 2013-2023 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//#############################################################################

//
// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "MEFs.h"

// Defines
//
////---------------- MEF Acci�n ----------------
//typedef enum {
//    Reset = 0,
//    Reposo,
//    Homming,
//    Trans_HS,
//    Trans_Temp,
//    Trans_Corr,
//    Trans_Pos,
//    Almacenar_ref,
//}Enum_est_Accion;
//
////---------------- MEF Recepci�n ----------------
//typedef enum
//{
//    reposo = 0,
//    comando,
//    J1B1,
//    J1B2,
//    J2B1,
//    J2B2,
//    J3B1,
//    J3B2,
//}Enum_est_Recep;
//
//typedef enum
//{
//    Nada = 0,
//    Inicializar,
//    Home_switch,
//    Temperaturas,
//    Corrientes,
//    Posiciones,
//    Referencias,
//}Comando_recibido_enum;
//
////Los siguientes bits los voy a leer �nicamente si llega un R
//#define b0(x)         (x == 'I' || x == 'H' || x == 'T' || x == 'C' || x == 'P' || x == 'R') //Comandos
//
//union float_union {
//    float float_value;
//    uint8_t byte_array[4];
//} FloatToByte;
//
//union int32_union {
//    int32_t float_value;
//    uint8_t byte_array[4];
//} Int32ToByte;
//
//union uchar_union {
//    int int_value;
//    unsigned char char_value[2];
//} IntToChar, CharToInt;
//
//union uint16_union {
//    int int_value;
//    uint16_t uint_value;
//} IntToUint;
//
//
//
///*==================[Variables mefs]==========================*/
//static int32_t ret;             // Number of bytes received.
////static uint8_t buffer[20];      // Ring Buffer.
//static int8_t transmision[7];      // Frame.
//static int instruccion = 0;        // Frame check flag.
//static Comando_recibido_enum comando_recibido = Nada;
//
//
volatile int HOME_SW_1 = 0, HOME_SW_2 = 0, HOME_SW_3 = 0; //varialbes home switch
volatile int TEMP_1=15, TEMP_2=45, TEMP_3=80;
volatile float Corr_1=0, Corr_2=10, Corr_3=25.26;
volatile int32_t ANG_1=15, ANG_2=45, ANG_3=67000;
volatile int16_t angulo_1, angulo_2, angulo_3;





//
// Define AUTOBAUD to use the autobaud lock feature
//#define AUTOBAUD

//
// Globals
//
uint16_t loopCounter = 0;

//
// Main
//
void main(void)
{
//    uint16_t receivedChar;
    unsigned char *ida_y_vuelta;
    unsigned char *msg;
//    uint16_t rxStatus = 0U;

    //
    // Configure PLL, disable WD, enable peripheral clocks.
    //
    Device_init();

    //
    // Disable pin locks and enable internal pullups.
    //
    Device_initGPIO();

    //
    // Configuration for the SCI Rx pin.
    //
    GPIO_setMasterCore(19, GPIO_CORE_CPU1);
    GPIO_setPinConfig(GPIO_19_SCIRXDB);
    GPIO_setDirectionMode(19, GPIO_DIR_MODE_IN);
    GPIO_setPadConfig(19, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(19, GPIO_QUAL_ASYNC);

    //
    // Configuration for the SCI Tx pin.
    //
    GPIO_setMasterCore(18, GPIO_CORE_CPU1);
    GPIO_setPinConfig(GPIO_18_SCITXDB);
    GPIO_setDirectionMode(18, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(18, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(18, GPIO_QUAL_ASYNC);

    //
    // Initialize interrupt controller and vector table.
    //
    Interrupt_initModule();
    Interrupt_initVectorTable();

    //
    // Initialize SCIA and its FIFO.
    //
    SCI_performSoftwareReset(SCIB_BASE);

    //
    // Configure SCIA for echoback.
    //
    SCI_setConfig(SCIB_BASE, DEVICE_LSPCLK_FREQ, 9600, (SCI_CONFIG_WLEN_8 | // Dice 9600, pero es en realidad 4800 (Todas mienten)
                                                        SCI_CONFIG_STOP_ONE |
                                                        SCI_CONFIG_PAR_NONE));
    SCI_resetChannels(SCIB_BASE);
    SCI_resetRxFIFO(SCIB_BASE);
    SCI_resetTxFIFO(SCIB_BASE);
    SCI_clearInterruptStatus(SCIB_BASE, SCI_INT_TXFF | SCI_INT_RXFF);
    SCI_enableFIFO(SCIB_BASE);
    SCI_enableModule(SCIB_BASE);
    SCI_performSoftwareReset(SCIB_BASE);

#ifdef AUTOBAUD
    //
    // Perform an autobaud lock.
    // SCI expects an 'a' or 'A' to lock the baud rate.
    //
    SCI_lockAutobaud(SCIB_BASE);
#endif

    //
    // Send starting message.
    //
//    msg = "Hello World!\n";
//    SCI_writeCharArray(SCIB_BASE, (uint16_t*)msg, 14);
//    msg = "You will enter a character, and the DSP will echo it back!\n";
//    SCI_writeCharArray(SCIB_BASE, (uint16_t*)msg, 61);
//
//    SCI_readCharArray(SCIB_BASE, (uint16_t*)ida_y_vuelta, 14);

//    rxStatus = SCI_getRxStatus(SCIB_BASE);
//        if((rxStatus & SCI_RXSTATUS_ERROR) != 0)
//        {
//            //
//            //If Execution stops here there is some error
//            //Analyze SCI_getRxStatus() API return value
//            //
//            ESTOP0;
//        }

    //
    // Echo back the character.
    //
//    msg = "You sent: ";
//    SCI_writeCharArray(SCIB_BASE, (uint16_t*)msg, 11);
//
//    SCI_writeCharArray(SCIB_BASE, (uint16_t*)ida_y_vuelta, 14);

    for(;;)
    {
        MEF_Recepcion();
        if(instruccion){
            MEF_Transmision();
        }


        //
        // Increment the loop count variable.
        //
        loopCounter++;
    }
}

//
// End of File
//

