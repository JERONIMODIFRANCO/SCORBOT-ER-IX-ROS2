################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../2837xD_RAM_lnk_cpu1.cmd 

LIB_SRCS += \
C:/ti/c2000_v5/C2000Ware_5_01_00_00/driverlib/f2837xd/driverlib/ccs/Debug/driverlib.lib 

C_SRCS += \
../MEFs.c \
../main.c 

C_DEPS += \
./MEFs.d \
./main.d 

OBJS += \
./MEFs.obj \
./main.obj 

OBJS__QUOTED += \
"MEFs.obj" \
"main.obj" 

C_DEPS__QUOTED += \
"MEFs.d" \
"main.d" 

C_SRCS__QUOTED += \
"../MEFs.c" \
"../main.c" 


