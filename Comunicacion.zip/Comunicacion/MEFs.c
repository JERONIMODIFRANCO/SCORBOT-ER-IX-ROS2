/*
 * MEFs.c
 *
 *  Created on: 17 dic. 2023
 *      Author: gasti
 */

#include "MEFs.h"

union float_union {
    float float_value;
    uint8_t byte_array[4];
} FloatToByte;


void Int32ToByte(int32_t int_value, uint16_t *byte_array){
    uint32_t temp;
    memcpy(&temp, &int_value, sizeof(int_value));
    byte_array[3] = (temp >> 24) & 0xFF;
    byte_array[2] = (temp >> 16) & 0xFF;
    byte_array[1] = (temp >> 8) & 0xFF;
    byte_array[0] = temp & 0xFF;
}

void ByteToInt16(volatile int16_t* int_value, uint16_t byte1, uint16_t byte2){
    *int_value = (int16_t)byte2 + ((int16_t)byte1 << 8);
}

void Float2Byte(float float_value, uint16_t *byte_array){
    uint32_t temp;
    memcpy(&temp, &float_value, sizeof(float_value));
    byte_array[0] = (temp >> 24) & 0xFF;
    byte_array[1] = (temp >> 16) & 0xFF;
    byte_array[2] = (temp >> 8) & 0xFF;
    byte_array[3] = temp & 0xFF;
}


//union int32_union {
//    int32_t int_value;
//    uint8_t byte_array[4];
//} Int32ToByte;

union uchar_union {
    int int_value;
    unsigned char char_value[2];
} IntToChar, CharToInt;

union uint16_union {
    int int_value;
    uint16_t uint_value;
} IntToUint;


/*==================[Variables mefs]==========================*/
static int32_t ret;             // Number of bytes received.
//static uint8_t buffer[20];      // Ring Buffer.
static uint16_t transmision[7];      // Frame.
int instruccion = 0;        // Frame check flag.
static Comando_recibido_enum comando_recibido = Nada;

extern volatile int HOME_SW_1, HOME_SW_2, HOME_SW_3; //varialbes home switch
extern volatile int TEMP_1, TEMP_2, TEMP_3;
extern volatile float Corr_1, Corr_2, Corr_3;
extern volatile int32_t ANG_1, ANG_2, ANG_3;
extern volatile int16_t angulo_1, angulo_2, angulo_3;

/*==================[MEFs]==========================*/

//---------------- MEF recepci�n ----------------
void MEF_Recepcion(void){
    static Enum_est_Recep est_mef_recep = reposo;
    static uint16_t receivedChar;
//    static unsigned char *msg;
    static uint16_t rxStatus = 0U;

    switch (est_mef_recep){
    case reposo:

        if(!instruccion){
            est_mef_recep = comando;
        }
        break;

    case comando:

        ret = SCI_getRxFIFOStatus(SCIB_BASE);

        if (ret){
            receivedChar = SCI_readCharBlockingFIFO(SCIB_BASE);
            rxStatus = SCI_getRxStatus(SCIB_BASE);
            if((rxStatus & SCI_RXSTATUS_ERROR) != 0)
            {
                ESTOP0;
            }
//            if (b0(receivedChar)){
                transmision[0] = receivedChar;
                SCI_writeCharBlockingFIFO(SCIB_BASE, receivedChar);

                switch (transmision[0]){

                case 'I':
                    comando_recibido = Inicializar;
                    instruccion = 1;
                    est_mef_recep = reposo;
                    break;

                case 'H':
                    comando_recibido = Home_switch;
                    instruccion = 1;
                    est_mef_recep = reposo;
                    break;

                case 'T':
                    comando_recibido = Temperaturas;
                    instruccion = 1;
                    est_mef_recep = reposo;
                    break;

                case 'C':
                    comando_recibido = Corrientes;
                    instruccion = 1;
                    est_mef_recep = reposo;
                    break;

                case 'P':
                    comando_recibido = Posiciones;
                    instruccion = 1;
                    est_mef_recep = reposo;
                    break;

                case 'R':
                    comando_recibido = Referencias;
                    est_mef_recep = J1B1;
                    break;
                }
//            }
        }

    break;

    case J1B1:

        ret = SCI_getRxFIFOStatus(SCIB_BASE);

        if (ret){
            transmision[1] = SCI_readCharBlockingFIFO(SCIB_BASE)-48;
            SCI_writeCharBlockingFIFO(SCIB_BASE, (transmision[1]+48));
            est_mef_recep = J1B2;
        }

        break;

    case J1B2:

        ret = SCI_getRxFIFOStatus(SCIB_BASE);

        if (ret){
            transmision[2] = SCI_readCharBlockingFIFO(SCIB_BASE)-48;
            SCI_writeCharBlockingFIFO(SCIB_BASE, (transmision[2]+48));
            est_mef_recep = J2B1;
        }

        break;

    case J2B1:

        ret = SCI_getRxFIFOStatus(SCIB_BASE);

        if (ret){
            transmision[3] = SCI_readCharBlockingFIFO(SCIB_BASE)-48;
            SCI_writeCharBlockingFIFO(SCIB_BASE, (transmision[3]+48));
            est_mef_recep = J2B2;
        }

        break;

    case J2B2:

        ret = SCI_getRxFIFOStatus(SCIB_BASE);

        if (ret){
            transmision[4] = SCI_readCharBlockingFIFO(SCIB_BASE)-48;
            SCI_writeCharBlockingFIFO(SCIB_BASE, (transmision[4]+48));
            est_mef_recep = J3B1;
        }

        break;

    case J3B1:

        ret = SCI_getRxFIFOStatus(SCIB_BASE);

        if (ret){
            transmision[5] = SCI_readCharBlockingFIFO(SCIB_BASE)-48;
            SCI_writeCharBlockingFIFO(SCIB_BASE, (transmision[5]+48));
            est_mef_recep = J3B2;
        }

        break;

    case J3B2:

        ret = SCI_getRxFIFOStatus(SCIB_BASE);

        if (ret){
            transmision[6] = SCI_readCharBlockingFIFO(SCIB_BASE)-48;
            SCI_writeCharBlockingFIFO(SCIB_BASE, (transmision[6]+48));
            est_mef_recep = reposo;
            instruccion = 1;
        }

        break;
    }
}


//---------------- MEF accion -------------------
void MEF_Transmision(void) {
    static Enum_est_Accion est_mef_Acc = Reposo;
    static int acc_terminada = 0;
    static uint16_t receivedChar = 10;
    static uint16_t bytes_transm[4];

    switch (est_mef_Acc) {

//        case Reset:
//            est_mef_Acc = Reposo;
//            break;

        case Reposo:
            if(instruccion == 1){
                switch (comando_recibido){
                case Inicializar:
                    est_mef_Acc = Homming;
                    break;

                case Home_switch:
                    est_mef_Acc = Trans_HS;
                    break;

                case Temperaturas:
                    est_mef_Acc = Trans_Temp;
                    break;

                case Corrientes:
                    est_mef_Acc = Trans_Corr;
                    break;

                case Posiciones:
                    est_mef_Acc = Trans_Pos;
                    break;

                case Referencias:
                    est_mef_Acc = Almacenar_ref;
                    break;
                }

//                SCI_writeCharArray(SCIB_BASE, (uint16_t*)&inst, 7);

            }

            break;

        case Homming:
//            acc_terminada = homming();
            acc_terminada = 1;
            if(acc_terminada){
                est_mef_Acc = Reposo;
                instruccion = false;
            }
            break;

        case Trans_HS:
            IntToUint.int_value = HOME_SW_1;
            SCI_writeCharBlockingFIFO(SCIB_BASE, receivedChar);
            SCI_writeCharBlockingFIFO(SCIB_BASE, (unsigned char)IntToUint.uint_value);
            IntToUint.int_value = HOME_SW_2;
            SCI_writeCharBlockingFIFO(SCIB_BASE, (IntToUint.uint_value + 48));
            IntToUint.int_value = HOME_SW_3;
            SCI_writeCharBlockingFIFO(SCIB_BASE, (IntToUint.uint_value + 48));

            acc_terminada = 1;
            if(acc_terminada){
                est_mef_Acc = Reposo;
                instruccion = false;
            }
            break;

        case Trans_Temp:
            IntToUint.int_value = TEMP_1;
            SCI_writeCharBlockingFIFO(SCIB_BASE, receivedChar);
            SCI_writeCharBlockingFIFO(SCIB_BASE, (IntToUint.uint_value + 48));
            IntToUint.int_value = TEMP_2;
            SCI_writeCharBlockingFIFO(SCIB_BASE, (IntToUint.uint_value + 48));
            IntToUint.int_value = TEMP_3;
            SCI_writeCharBlockingFIFO(SCIB_BASE, (IntToUint.uint_value + 48));

            acc_terminada = 1;
            if(acc_terminada){
                est_mef_Acc = Reposo;
                instruccion = false;
            }
            break;

        case Trans_Corr:
            Float2Byte(Corr_1,bytes_transm);
            SCI_writeCharBlockingFIFO(SCIB_BASE, 32);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[0]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[1]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[2]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[3]);
            Float2Byte(Corr_2,bytes_transm);
            SCI_writeCharBlockingFIFO(SCIB_BASE, 32);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[0]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[1]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[2]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[3]);
            Float2Byte(Corr_3,bytes_transm);
            SCI_writeCharBlockingFIFO(SCIB_BASE, 32);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[0]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[1]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[2]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[3]);

            acc_terminada = 1;
            if(acc_terminada){
                est_mef_Acc = Reposo;
                instruccion = false;
            }
            break;
        case Trans_Pos:
            Int32ToByte(ANG_1,bytes_transm);
            SCI_writeCharBlockingFIFO(SCIB_BASE, 32);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[0]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[1]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[2]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[3]);
            Int32ToByte(ANG_2,bytes_transm);
            SCI_writeCharBlockingFIFO(SCIB_BASE, 32);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[0]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[1]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[2]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[3]);
            Int32ToByte(ANG_3,bytes_transm);
            SCI_writeCharBlockingFIFO(SCIB_BASE, 32);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[0]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[1]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[2]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, bytes_transm[3]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, receivedChar);

            acc_terminada = 1;
            if(acc_terminada){
                est_mef_Acc = Reposo;
                instruccion = false;
            }
            break;

        case Almacenar_ref:
            ByteToInt16(&angulo_1, transmision[1], transmision[2]);
            ByteToInt16(&angulo_2, transmision[3], transmision[4]);
            ByteToInt16(&angulo_3, transmision[5], transmision[6]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, receivedChar);
            SCI_writeCharBlockingFIFO(SCIB_BASE, transmision[1]);
            SCI_writeCharBlockingFIFO(SCIB_BASE, transmision[2]);
            acc_terminada = 1;
            if(acc_terminada){
                est_mef_Acc = Reposo;
                instruccion = false;
            }
            break;
    }
}
