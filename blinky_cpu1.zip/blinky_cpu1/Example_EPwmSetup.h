/*
 * Example_EPwmSetup.h
 *
 *  Created on: 18 may. 2020
 *      Author: FACU
 */

#ifndef EXAMPLE_EPWMSETUP_H_
#define EXAMPLE_EPWMSETUP_H_

void initEpwm(void);

#endif /* EXAMPLE_EPWMSETUP_H_ */
