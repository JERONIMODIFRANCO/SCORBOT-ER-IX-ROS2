/*
 * Entradas_Salidas.h
 *
 *  Created on: 28 may. 2020
 *      Author: FACU
 */

#ifndef ENTRADAS_SALIDAS_H_
#define ENTRADAS_SALIDAS_H_

extern void Entradas_Salidas_init(void);

#endif /* ENTRADAS_SALIDAS_H_ */
