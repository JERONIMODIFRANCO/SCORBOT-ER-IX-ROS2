/*
 * seteo_salidas.h
 *
 *  Created on: 18 may. 2020
 *      Author: FACU
 */

#ifndef SETEO_SALIDAS_H_
#define SETEO_SALIDAS_H_


void Set_Salidas();


#endif /* SETEO_SALIDAS_H_ */
