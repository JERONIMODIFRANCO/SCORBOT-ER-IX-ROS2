/*
 * init_PWM_motor_1_2_3.h
 *
 *  Created on: 18 may. 2020
 *      Author: FACU
 */

#ifndef INIT_PWM_MOTOR_1_2_3_H_
#define INIT_PWM_MOTOR_1_2_3_H_

void InitEPwm2(Uint16, Uint16, Uint16);
void InitEPwm3(Uint16, Uint16, Uint16);
void InitEPwm4(Uint16, Uint16, Uint16);
void InitEPwm5(void);

#endif /* INIT_PWM_MOTOR_1_2_3_H_ */
